/* (The MIT License)
Copyright (c) 2006 Adam Bennett (cruxic@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 */
package adamb.ogg;

import java.io.*;
import adamb.Util;

/**
 Iterates over pages in an Ogg physical bitstream.
 */
public class PhysicalPageStream
  implements LogicalPageStream
{
  private InputStream is;
  private OggCRC oggCRC;
	private boolean foundPageMarkedAsLast;
	private int lastPageSequenceNumber;
	private boolean startMidStream;

  
  /**
   the Ogg stream capture pattern
   */
  static final byte[] OGG_STREAM_CAPTURE_PATTERN = {(byte)'O', (byte)'g', (byte)'g',(byte)'S'};
  
  public PhysicalPageStream(InputStream markableInputStream, boolean startMidStream)
		throws UnsupportedOperationException
  {
		if (!markableInputStream.markSupported())
			throw new UnsupportedOperationException("Given input stream does not support mark and reset operations!");
		
    this.is = markableInputStream;
    oggCRC = new OggCRC();
		foundPageMarkedAsLast = false;
		lastPageSequenceNumber = Integer.MIN_VALUE;
		this.startMidStream = startMidStream;
  }
	
  public PhysicalPageStream(InputStream markableInputStream)
		throws UnsupportedOperationException
	{
		this(markableInputStream, false);
	}
  
  public Page next()
  throws IOException
  {
		boolean haveCapture = false;
		
		while (true)
		{
			//mark the stream before reading the next page
			is.mark(Page.MAX_PAGE_SIZE + 8);  //8 is a fudge factor, I don't think I need it but just in case...
			
			try
			{
				//try read a page
				Page page = new Page();
				if (readPageFromStream(page, is, oggCRC, haveCapture))
				{
					//validate the page CRC
					if (page.checksum == oggCRC.getValue())
					{
						//first page from the stream?
						if (lastPageSequenceNumber == Integer.MIN_VALUE)
						{
							//the first page in the stream must be marked as first!
							if (!page.isFirst && !startMidStream)
								throw new IOException("First page from stream was not marked as first!");

							lastPageSequenceNumber = page.sequence;
						}
						else
						{
							//this is not the first page and thus it must not be marked so
							if (page.isFirst)
								throw new IOException("Page in mid stream marked as first!");

							//not missing any pages?
							if (page.sequence == lastPageSequenceNumber + 1)
								lastPageSequenceNumber++;
							else
								throw new IOException("Missing one or more pages in stream!  Jumped from " + lastPageSequenceNumber + " to " + page.sequence + ".");
						}						
						
						//there should not be any more pages after we find the one marked as last!
						if (page.isLast)
							foundPageMarkedAsLast = true;
						else if (foundPageMarkedAsLast)
							throw new IOException("Found more pages after the page marked as last!");
						
						return page;
					}
					//else corrupt page
				}
				else
					return null;
			}
			catch (InvalidHeaderException cpe)
			{

			}
			
			/*this point will only be reached if the next page was corrupt.
			 search the stream for the next page by searching for the capture pattern.
			 first we must reset the stream to the page start*/
			is.reset();
			//skip 1 byte so the search does not match immediately
			boolean skipped1 = is.read() != -1;
			assert skipped1;  //there should never be no problem skipping 1 byte because we know we the stream contains at least 4 bytes or at least a page

			if (Util.streamFind(is, OGG_STREAM_CAPTURE_PATTERN) != -1)
				haveCapture = true;
			else
				return null;
		}
  }
	
	private boolean readPageFromStream(Page page, InputStream is, OggCRC pageCRC, boolean haveCapture)
		throws IOException, InvalidHeaderException
	{
		byte[] fixedHeaderBytes;
		if (haveCapture)
			fixedHeaderBytes = new byte[Page.FIXED_HEADER_SIZE - PhysicalPageStream.OGG_STREAM_CAPTURE_PATTERN.length];
		else
			fixedHeaderBytes = new byte[Page.FIXED_HEADER_SIZE];
				
		int nRead = Util.readCompletely(is, fixedHeaderBytes);
		if (nRead == fixedHeaderBytes.length)
		{
			int segmentCount = page.parseFixedHeaderValues(fixedHeaderBytes);
			
			/*read the variable length segment table.  Does the spec allow an empty segment table?
				If so my code will not currently handle so I need to throw an error*/
			if (segmentCount > 0)
			{
				byte[] segmentTable = new byte[segmentCount];

				if (Util.readCompletely(is, segmentTable) == segmentTable.length)
				{
					int contentSize = page.parseSegmentTable(segmentTable);
					
					/*read the page contents*/
					page.content = new byte[contentSize];
					if (Util.readCompletely(is, page.content) == page.content.length)
					{
						///compute the CRC
						pageCRC.reset();
						
						//include the capture pattern if we don't already have it in the header data
						if (haveCapture)
							pageCRC.update(PhysicalPageStream.OGG_STREAM_CAPTURE_PATTERN);
						
						//zero out the checksum
						System.arraycopy(new byte[4], 0, fixedHeaderBytes, Page.HEADER_CHECKSUM_OFFSET, 4);
						
						pageCRC.update(fixedHeaderBytes);
						pageCRC.update(segmentTable);
						pageCRC.update(page.content);
						
						return true;
					}
					else
						throw new EOFException("partial page content due to eos");
				}
				else
					throw new EOFException("partial segment table due to eos");
			}
			else
				throw new IOException("Page with empty segment table encountered.  Not sure if the spec Ogg allows this...  Please consult with the library maintainer.");
		}
		//graceful end of stream?
		else if (nRead == 0)
			return false;
		//unexpected end of stream
		else
			throw new EOFException("partial header due to eos");		
	}
}



