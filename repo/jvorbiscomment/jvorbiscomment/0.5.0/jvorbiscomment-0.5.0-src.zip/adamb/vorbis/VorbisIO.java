/* (The MIT License)
Copyright (c) 2006 Adam Bennett (cruxic@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 */
package adamb.vorbis;


import org.junit.*;
import static org.junit.Assert.*;
import java.nio.channels.FileChannel;

import adamb.*;
import adamb.ogg.*;
import java.io.*;
import java.util.*;
import org.archive.io.*;

public class VorbisIO
{
	public static VorbisCommentHeader readComments(File f)
	throws IOException
	{
		LogicalPageStream lps = openOggFile(f);
		VorbisPacketStream vps = new VorbisPacketStream(new PacketStream(new PacketSegmentStream(lps)));
		//read id and comments
		vps.next();
		//read comments
		vps.next();
		
		return vps.getCommentHeader();
	}
	
	private static LogicalPageStream openOggFile(File f)
	throws IOException
	{
		return new PhysicalPageStream(new BufferedInputStream(new FileInputStream(f), 256 * 1024));
	}
	
	public static void writeComments(File f, VorbisCommentHeader newComments)
	throws IOException
	{
		///open the file for read/write
		//throw an exception if the file does not exist because RandomAccessFile will create it
		if (!f.exists())
			throw new FileNotFoundException(f.getPath() + " does not exist!");
		RandomAccessFile raf = new RandomAccessFile(f, "rw");
		RandomAccessInputStream rais = new RandomAccessInputStream(raf);
		PhysicalPageStream pps = new PhysicalPageStream(rais);
		VorbisPacketStream vps = new VorbisPacketStream(new PacketStream(new PacketSegmentStream(pps)));
		
		try
		{
			//read id packet
			Packet idPacket = vps.next();
			
			//read comment packet
			long commentPagePos = raf.getFilePointer();
			Packet comments = vps.next();
			int commentPageNum = comments.getStartingPage().sequence;
			
			/*build the new comments.  Ideally we will keep the exact same comment
			 size so that the entire file does not have to be re-written.  Therefore
			 we will use spaces at the end of the vendor string to give breathing room.*/
			byte[] newCommentPacket = newComments.toPacket();
			{
				int sizeDiff = comments.getBytes().length - newCommentPacket.length;
				
				/* The maxium amount of padding characters to use. Since we are
				 padding with spaces after the vendor string it is best to keep this
				 small.  That way, those few programs that read the vendor string,
				 without first trimming the whitespace, will not be flooded with
				 an unexpectedly large number of characters.*/
				final int RESIZE_THRESHOLD = 128;
			
				int fillAmount;
				//if new comments are just a bit smaller then use filler to make up the difference
				if (sizeDiff >= 0 && sizeDiff <= RESIZE_THRESHOLD)
						fillAmount = sizeDiff;
				//else, since we are going to have to grow the file we might as well add a little breathing room
				else
					fillAmount = RESIZE_THRESHOLD;
				
				if (fillAmount > 0)
				{
					StringBuilder sb = new StringBuilder(newComments.vendor.length() + fillAmount);
					sb.append(newComments.vendor);
					while (fillAmount > 0)
					{
						sb.append(' ');
						fillAmount--;
					}
					
					String oldVendor = newComments.vendor;
					newComments.vendor = sb.toString();
					newCommentPacket = newComments.toPacket();
					newComments.vendor = oldVendor;
				}
			}
			
			//only continue with the update if the new comments are different at all
			if (!Arrays.equals(newCommentPacket, comments.getBytes()))
			{
				//read setup
				Packet setup = vps.next();
				long firstAudioPagePos = raf.getFilePointer();
				int setupLastPageNum = setup.getLastSegment().getSourcePage().sequence;
				
				//System.out.println("Position: [" + commentPagePos + "," + firstAudioPagePos + ")");
				//System.out.println("Page sequence span [" + commentPageNum + "," + setupLastPageNum + "]");
				
				/*number of pages used for the comment and setup packets.  we will try
					to match this so that we can avoid changing the page sequence numbers
					for the entire stream*/
				int oldNumPagesUsed = setupLastPageNum - commentPageNum + 1;
				
				ArrayList<Page> pages = new ArrayList<Page>(4);
				if (oldNumPagesUsed == 1)
					pages.addAll(pagify(new byte[][]{newCommentPacket, setup.getBytes()}));
				else
				{
					pages.addAll(pagify(new byte[][]{newCommentPacket}));
					pages.addAll(pagify(new byte[][]{setup.getBytes()}));
				}
				
				//fill out the page header values
				{
					Page firstPage = idPacket.getStartingPage();
					int lastSequenceNumber = firstPage.sequence;
					for (Page page: pages)
					{
						page.streamSerialNumber = firstPage.streamSerialNumber;
						/*Vorbis I specification: "The granule position of these first pages containing only headers is zero."*/
						page.absGranulePos = 0;
						page.sequence = ++lastSequenceNumber;
						//currently this will always be zero but just to be flexible...
						page.streamStructureVersion = firstPage.streamStructureVersion;
						page.isFirst = false;
						page.isLast = false;
						//isContinued was filled out by pagify
					}
				}
				
				//create the page data array
				ByteArrayOutputStream bbos = new ByteArrayOutputStream(1024 * 8);
				OggCRC oggCRC = new OggCRC();
				for (Page p: pages)
					OggIO.writePageToStream(p, bbos, oggCRC);
				byte[] data = bbos.toByteArray();
				bbos = null; //free the memory
				
				//the amount to increase or decrease the page sequence number
				int pageSequenceAdjust = pages.size() - oldNumPagesUsed;
				
				/*we are ready to do our writing to the file.  It would be a cryin' shame
				 to corrupt to file!  It is very unlikely that FileInsert will fail and cause
				 corruption but if we need to update the sequence # on every page things start getting
				 scary because, currently my Ogg parsers are very strict and will fail upon any sin
				 within the Ogg stream.  This means that we might get halfway though updating the page
				 sequence numbers and bail for some silly reason.  Until I add "strictness" modes
				 to the Ogg parser I will make sure the stream is parsable beforehand.  On my
				 machine this isn't really a bit hit (it takes about 1% longer)*/
				
				//if a sequence adjustment is necessary  make sure the entire stream is intact/parsable
				boolean safetyFirstMode = true;
				if (pageSequenceAdjust != 0  && safetyFirstMode)
				{
					raf.seek(firstAudioPagePos);
					pps = new PhysicalPageStream(rais, true);
					Page page = pps.next();
					while (page != null)
						page = pps.next();
				}	
				
				//replace the old comment and setup pages with the new ones
				FileInsert fileInsert = new FileInsert(1024 * 512);
				fileInsert.insert(raf, commentPagePos, firstAudioPagePos, data, 0, data.length);
				
				//need to adjust?
				if (pageSequenceAdjust != 0)
				{
					//the audio packet page may have shifted from the insert operation
					firstAudioPagePos = commentPagePos + data.length;
					raf.seek(firstAudioPagePos);
					
					pps = new PhysicalPageStream(rais, true);
					RandomAccessOutputStream raos = new RandomAccessOutputStream(raf);
					
					/*IMPORTANT: remember that the page stream might not
					 be continguous in the file if there is corruption.*/
					Page page = pps.next();
					while (page != null)
					{
						//adjust the page sequence number
						page.sequence += pageSequenceAdjust;
						
						//seek back to the start of the page and rewrite the page
						raf.seek(raf.getFilePointer() - page.size());
						OggIO.writePageToStream(page, raos, oggCRC);  //todo: would it be faster to simply write the fixed header and skip over the content?
						
						//next page
						page = pps.next();
					}
				}
			}
		}
		finally
		{
			raf.close();
		}
	}
	
	/**put one or more packets on the minimum number of required pages*/
	private static ArrayList<Page> pagify(byte[][] packets)
	{
		assert packets.length > 0;
		
		ArrayList<Page> pages = new ArrayList<Page>(8);
		ByteArrayOutputStream content = new ByteArrayOutputStream(1024 * 16);
		
		int packetIdx = 0;
		int packetOffset = 0;
		int lastSegmentSize = 0;
		
		int pageSegOffset = 0;
		Page page = new Page();
		page.isContinued = false;  //we know for a fact that the first page will not continue any packets
		
		while (packetIdx < packets.length)
		{
			//work on an individual packet
			while (true)
			{
				//have room for another segment on this page?
				if (page.segments.size() < 255)
				{
					//any packet data left to copy?
					if (packetOffset < packets[packetIdx].length)
					{
						//write the segment data
						int remainder = packets[packetIdx].length - packetOffset;
						lastSegmentSize = Math.min(255, remainder);
						content.write(packets[packetIdx], packetOffset, lastSegmentSize);
						
						//add the segment object
						page.segments.add(new Segment(page, pageSegOffset, lastSegmentSize));
						
						packetOffset += lastSegmentSize;
						pageSegOffset += lastSegmentSize;
					}
					else
					{
						/*we are done with the packet.  If the last segment was 255 then we
						 need to write a 0 segment to denote the end of the packet.  From the spec:
						 
						"Note that a lacing value of 255 implies that a second lacing value follows
						 in the packet, and a value of < 255 marks the end of the packet after that
						 many additional bytes. A packet of 255 bytes (or a multiple of 255 bytes)
						 is terminated by a lacing value of 0"
						 */
						if (lastSegmentSize == 255)
							page.segments.add(new Segment(page, pageSegOffset, 0));
						
						//move on to the next packet
						break;
					}
				}
				//page is full.  start another page
				else
				{
					//copy in the content
					page.content = content.toByteArray();
					assert page.content.length == page.calculateContentSizeFromSegments();
					content.reset();
					pages.add(page);
					
					//prepare another page
					pageSegOffset = 0;
					Segment lastSegment = page.segments.get(page.segments.size() - 1);
					page = new Page();
					//this new page continues a packet if the previous page finished all it's packets
					page.isContinued = !lastSegment.isLast();
				}
			}
			
			packetIdx++;
			packetOffset = 0;
		}
		
		//add the remaining page only if it's not empty
		if (page.segments.size() > 0)
		{
			page.content = content.toByteArray();
			pages.add(page);
		}
		
		return pages;
	}
	
	public VorbisIO()
	{}
	
	@Test
	public void commentIOTest()
		throws IOException
	{
		//create the test file
		File f = new File("deleteme(commentIOTest).ogg");
		f.delete();
		copyFile(new File(new File("test oggs"), "blank_comments.ogg"), f);
		
		int[] changes = {0, 2, 1, 3};
		int[] scales = {1, 2, 100, 1111, 1024 * 125};
		long start = System.currentTimeMillis();
		for (int scale: scales)
		{
			for (int change: changes)
			{
				System.out.println(scale + "x" + change + "=" + (scale * change));
				String str = makeRandomString(scale * change);

				VorbisCommentHeader vch = new VorbisCommentHeader();
				vch.fields.add(new CommentField("T", str));
				
				writeComments(f, vch);
				vch = readComments(f);
				
				assertTrue(vch.vendor.trim().length() == 0);
				assertTrue(vch.fields.size() == 1);
				assertTrue(vch.fields.get(0).name.equals("T"));
				assertTrue(vch.fields.get(0).value.equals(str));
			}
		}
		System.out.println(System.currentTimeMillis() - start);
	}
	
	private String makeRandomString(int numChars)
	{
		byte[] numbers = new byte[numChars];
		new Random().nextBytes(numbers);
		StringBuilder sb = new StringBuilder(numChars);
		for (byte b: numbers)
		{
			char c = (char)Math.abs((int)b);
			if (c < ' ')
				c = ' ';
			else if (c > '~')
				c = ' ';
			
			sb.append(c);
		}
		
		return sb.toString();
	}
		
	private void copyFile(File in, File out)
	throws IOException
	{
		FileInputStream fis = new FileInputStream(in);
		FileOutputStream fos = new FileOutputStream(out);
		
		FileChannel sourceChannel = fis.getChannel();
		FileChannel destinationChannel = fos.getChannel();
		
		sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);

		destinationChannel.close();
		sourceChannel.close();
		fos.close();
		fis.close();
	}
	
	//@Test
	public void pagifyTest()
	{
		//sanity test for makePackets
		{
			byte[][] packets = makePackets(0,1,2,3,399);
			assertTrue(packets[0].length == 0);
			assertTrue(packets[1].length == 1);
			assertTrue(packets[2].length == 2);
			assertTrue(packets[3].length == 3);
			assertTrue(packets[4].length == 399);
		}
		
		//1 packet: size 1
		assertTrue(pagifyTestHelper(makePackets(1), new int[]{1}, 1));
		
		//1 packet: 255
		assertTrue(pagifyTestHelper(makePackets(255), new int[]{255}, 2));
		
		//1 packet: 256
		assertTrue(pagifyTestHelper(makePackets(256), new int[]{256}, 2));
		
		//2 packets: 1, 1
		assertTrue(pagifyTestHelper(makePackets(1,1), new int[]{2}, 2));
		
		//2 packets: 255, 1
		assertTrue(pagifyTestHelper(makePackets(255,1), new int[]{256}, 3));
		
		//2 packets: 1, 255
		assertTrue(pagifyTestHelper(makePackets(1,255), new int[]{256}, 3));
		
		//2 packets: 255, 255
		assertTrue(pagifyTestHelper(makePackets(255,255), new int[]{510}, 4));
		
		//3 packets: 1,1,1
		assertTrue(pagifyTestHelper(makePackets(1,1,1), new int[]{3}, 3));
		
		//4 packets: 1,256,255,1
		assertTrue(pagifyTestHelper(makePackets(1,256,255,1), new int[]{513}, 6));
		
		//1 page can hold 255 packets if they are of size 254
		{
			int[] sizes = new int[255];
			for (int i = 0; i < sizes.length; i++)
				sizes[i] = 254;
			assertTrue(pagifyTestHelper(makePackets(sizes), new int[]{254*255}, 255));
		}
		
		//254 packets size 254 and one size 255 requires 2 pages, the second will have no data though
		{
			int[] sizes = new int[255];
			for (int i = 0; i < sizes.length; i++)
				sizes[i] = 254;
			sizes[254] = 255;
			assertTrue(pagifyTestHelper(makePackets(sizes), new int[]{254*254+255, 0}, 255, 1));
		}
		
		//same as above except the size 255 is in the middle causing the second page to have data
		{
			int[] sizes = new int[255];
			for (int i = 0; i < sizes.length; i++)
				sizes[i] = 254;
			sizes[100] = 255;
			assertTrue(pagifyTestHelper(makePackets(sizes), new int[]{253*254+255, 254}, 255, 1));
		}
		
		//1 big packet that fills exactly 1 page
		assertTrue(pagifyTestHelper(makePackets(255*255 - 1), new int[]{255*255 - 1}, 255));
		
		//maximum content size requires a second, empty page
		assertTrue(pagifyTestHelper(makePackets(255*255), new int[]{255*255, 0}, 255, 1));
		
		//greater than maximum content size requires 2 pages
		assertTrue(pagifyTestHelper(makePackets(255*255 + 99), new int[]{255*255, 99}, 255, 1));
		
		//2 packets one 1 page where both packets are the largest size possible without needing another page
		assertTrue(pagifyTestHelper(makePackets(32384, 32639), new int[]{255*255-2}, 255));
		
		//2 packets each maximum content size requires 3 pages
		assertTrue(pagifyTestHelper(makePackets(255 * 255, 255 * 255), new int[]{255*255, 254*255, 255}, 255, 255, 2));
		
		///1MB packet
		{
			int[] sizes = new int[17];
			
			//first 16 pages will be completely full
			for (int i = 0; i < sizes.length; i++)
				sizes[i] = 255*255;
			//last page will have 8176
			sizes[16] = 8176;
			
			int[] nSegs = new int[17];
			//first 16 pages will have 255 segments
			for (int i = 0; i < nSegs.length; i++)
				nSegs[i] = 255;
			//last page will have 33
			nSegs[16] = 33;
			
			assertTrue(pagifyTestHelper(makePackets(1024 * 1024), sizes, nSegs));
		}
	}
	
	private byte[][] makePackets(int... lengths)
	{
		byte[][] packets = new byte[lengths.length][];
		Random rnd = new Random();
		for (int i = 0; i < packets.length; i++)
		{
			packets[i] = new byte[lengths[i]];
			rnd.nextBytes(packets[i]);
		}
		return packets;
	}
	
	private boolean pagifyTestHelper(byte[][] packets, int[] contentSizeOnPages,  int... numSegmentsOnPages)
	{
		assert numSegmentsOnPages.length > 0;
		try
		{
			List<Page> pages = pagify(packets);
			
			assertTrue(pages.size() == numSegmentsOnPages.length);
			assertTrue(contentSizeOnPages.length == numSegmentsOnPages.length);
			
			//validate the correct number of segments on each page
			for (int i = 0; i < numSegmentsOnPages.length; i++)
				assertTrue(pages.get(i).segments.size() == numSegmentsOnPages[i]);
			
			//validate the correct content size on each page
			for (int i = 0; i < contentSizeOnPages.length; i++)
			{
				assertTrue(pages.get(i).content.length == contentSizeOnPages[i]);
				assertTrue(pages.get(i).calculateContentSizeFromSegments() == contentSizeOnPages[i]);
			}
			
			int lastSeqNumber = 0;
			for (Page page: pages)
				page.sequence = ++lastSeqNumber;
			
			if (pages.size() > 0)
			{
				pages.get(0).isFirst = true;
				pages.get(pages.size() - 1).isLast = true;
			}
			
			PacketStream ps = new PacketStream(new PacketSegmentStream(new CollectionPageStream(pages.iterator())));
			int i = 0;
			do
			{
				Packet packet = ps.next();
				if (packet != null)
				{
					if (Arrays.equals(packet.getBytes(), packets[i]))
						i++;
					else
						return false;
				}
				else
					return i == packets.length;
			}
			while (true);
		}
		catch (IOException ie)
		{
			//should never happen?
			assert false: ie.toString();
			return false;
		}
	}
	
	private class CollectionPageStream implements LogicalPageStream
	{
		private Iterator<Page> pages;
		
		public CollectionPageStream(Iterator<Page> pages)
		{
			this.pages = pages;
			
		}
		
		public Page next()
		throws java.io.IOException
		{
			if (pages.hasNext())
				return pages.next();
			else
				return null;
		}
	}
}
