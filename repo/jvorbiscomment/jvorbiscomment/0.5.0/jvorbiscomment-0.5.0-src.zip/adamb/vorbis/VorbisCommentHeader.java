/* (The MIT License)
Copyright (c) 2006 Adam Bennett (cruxic@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 */
package adamb.vorbis;

import adamb.Util;
import adamb.ogg.*;
import java.util.*;
import java.io.*;

public class VorbisCommentHeader
{
	public String vendor;
	public List<CommentField> fields;
	
	public VorbisCommentHeader()
	{
		vendor = "";
		fields = new ArrayList<CommentField>(32);
	}
	
	VorbisCommentHeader(Packet packet)
	throws IOException
	{
		this();
		VorbisPacketStream.validateHeaderPacket(packet, VorbisPacketStream.COMMENT_HEADER_TYPE);
		byte[] data = packet.getBytes();
		
		int i = 1 + VorbisPacketStream.VORBIS.length;
		
		//vendor length
		ensureData(i, 4, data);
		int len = Util.asIntLE(data, i, 4);
		i += 4;
		
		//vendor string
		ensureData(i, len, data);
		vendor = Util.asUTF8(data, i, len).trim();
		if (vendor == null)
			throw new IOException("Invalid UTF-8 in vendor string");
		i += len;
		
		//number of user fields
		ensureData(i, 4, data);
		int nFields = Util.asIntLE(data, i, 4);
		i += 4;
		
		//read user fields
		for (int j = 0; j < nFields; j++)
		{
			//field length
			ensureData(i, 4, data);
			len = Util.asIntLE(data, i, 4);
			i += 4;
			
			//field string
			ensureData(i, len, data);
			String str = Util.asUTF8(data, i, len);
			i += len;
			if (str != null)
				fields.add(new CommentField(str));
			else
				throw new IOException("Invalid UTF-8 in vendor string");
		}
		
		//skip framing byte
		i++;
		//must be at end of packet
		if (i != data.length)
			throw new IOException("Vorbis comment structure does not fill comment packet!");
	}
	
	public byte[] toPacket()
	{
		ByteArrayOutputStream s = new ByteArrayOutputStream(2048);
		
		try
		{
			//type and "vorbis"
			s.write(VorbisPacketStream.COMMENT_HEADER_TYPE);
			s.write(VorbisPacketStream.VORBIS);
			
			//vendor
			byte[] utf8 = vendor.getBytes("UTF-8");
			s.write(Util.intLE(utf8.length));
			s.write(utf8);
			
			//number of fields
			s.write(Util.intLE(fields.size()));
			
			//fields
			StringBuilder sb = new StringBuilder(128);
			for (CommentField field: fields)
			{
				sb.setLength(0);
				sb.append(field.name);
				sb.append('=');
				sb.append(field.value);
				
				utf8 = sb.toString().getBytes("UTF-8");
				s.write(Util.intLE(utf8.length));
				s.write(utf8);
			}
			
			//framing flag
			s.write(1);
		}
		catch (IOException iex)
		{}
		
		return s.toByteArray();
	}
	
	private void ensureData(int offset, int amount, byte[] data)
	throws IOException
	{
		if (offset + amount > data.length)
			throw new IOException("Vorbis comment header is incomplete.");
	}
	
	public void print()
	{
		System.out.println("vendor=" + vendor);
		for (CommentField cf: fields)
		{
			System.out.print(cf.name);
			System.out.print('=');
			System.out.println(cf.value);
		}
	}
}