/* (The MIT License)
Copyright (c) 2006 Adam Bennett (cruxic@gmail.com)

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 */
package adamb;

import java.util.*;
import java.io.*;
import java.nio.charset.*;
import java.nio.*;

import org.junit.*;
import static org.junit.Assert.*;

public class Util
{
  
  public static int ubyte(byte b)
  {
    return b & 0xFF;
  }
  
  public static byte ubyte(int i)
  {
    assert i > -1 && i < 256;
    return (byte)i;
  }
  
  public static boolean startsWith(byte[] a, byte[] a2)
  {
    return intervalEquals(a, 0, a2);
  }
  
  public static boolean intervalEquals(byte[] a, int offset, byte[] a2)
  {
    if ((a.length - offset) >= a2.length)
    {
      for (int i = 0; i < a2.length; i++)
      {
        if (a[i + offset] != a2[i])
          return false;
      }
      
      return true;
    }
    else
      return false;
  }
  
  //static boolean arrayEquals(byte[] a, int offset1, byte[] a2, int offset2)
  
        /*block until the given byte array can be filled from the stream
                @return the number bytes actually read.  This will only be less than the length
                of the byte array if the end of the stream is reached.
         */
  public static int readCompletely(InputStream is, byte[] bytes)
  throws IOException
  {
    int nRead = is.read(bytes);
    while (nRead < bytes.length)
    {
      if (nRead == -1)
        return 0;
      else
        nRead += is.read(bytes, nRead, bytes.length - nRead);
    }
    
    return nRead;
  }
	
  public static String printBytes(byte[] bytes)
  {
    StringBuilder sb = new StringBuilder(bytes.length * 4 + 32);
    for (byte b: bytes)
    {
      String s = Integer.toHexString(ubyte(b));
      if (s.length() == 1)
        sb.append('0');
      sb.append(s.toUpperCase());
      sb.append(' ');
    }
    
    return sb.toString();
  }
  
  public static byte[] concat(byte[] a, byte[] a2, byte[] a3)
  {
    byte[] all = new byte[a.length + a2.length + a3.length];
    System.arraycopy(a, 0, all, 0, a.length);
    System.arraycopy(a2, 0, all, a.length, a2.length);
    System.arraycopy(a3, 0, all, a.length + a2.length, a3.length);
    return all;
  }
  
  public static int asIntBE(byte[] b, int offset, int length)
  {
    int t = 0;
    for (int i= 0; i < length; i++)
      t = (t<<8) + (b[i + offset] & 0xFF);
    return t;
  }
  
  public static int asIntLE(byte[] b, int offset, int length)
  {
    assert length > 0 && length < 5;
    int t = 0;
    for (int i = length; i-- > 0;)
      t	= (t<<8) + (b[i + offset] & 0xFF);
    return t;
  }

	/*
	public static void intLE(int value, byte[] bytes, int offset)
	{
		ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).putInt(value);
		return bytes;
	}	*/
	
	public static byte[] intLE(int value)
	{
		byte[] bytes = new byte[4];
		ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).putInt(value);
		return bytes;
	}
	
	public static byte[] longLE(long value)
	{
		byte[] bytes = new byte[8];
		ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).putLong(value);
		return bytes;
	}
        /*
                @return null if the given bytes are not value UTF-8 encoded
         */
  public static String asUTF8(byte[] bytes, int offset, int length)
  {
    try
    {
      Charset charset = Charset.forName("UTF-8");
      CharsetDecoder decoder = charset.newDecoder();
      return decoder.decode(ByteBuffer.wrap(bytes, offset, length)).toString();
    }
    catch (MalformedInputException ex)
    {
      ex.printStackTrace();
    }
    catch (UnmappableCharacterException uc)
    {
     uc.printStackTrace();
    }
    catch (CharacterCodingException cc)
    {
      cc.printStackTrace();
    }
    
    return null;
  }
  
  public static long asLongLE(byte[] b, int offset, int length)
  {
    assert length > 0 && length < 9;
    long t = 0;
    for (int i = length; i-- > 0;)
      t	= (t<<8) + (b[i + offset] & 0xFF);
    return t;
  }
  
  public static int lowNibble(byte b)
  {
    return b & 0xF;
  }
  
  public static int highNibble(byte b)
  {
    return Util.ubyte(b) >>> 4;
  }
	
	/**
	 Find the specified byte pattern in the input stream.
	 If the pattern is found the input stream will be positioned
	 to read the byte directly after the pattern.  If the stream does not
	 contain the pattern it will be consumed completely.
	 
	 	 
	 @param is the stream to search.  Mark and reset does NOT need to be supported
	 @param pattern the byte pattern to search for.  Must be at least 1 byte.
	 @return the offset from the initial stream position to pattern (-1 if the pattern was not found).  For example if you call streamFind when the pattern is the very next part of the stream, 0 will be returned (found immediately).  If the pattern is 5 bytes a way when you call streamFind, 5 will be returned.
	 @todo: 1) test this and 2) it would be handy if this function could optionally mark the stream
	   at the start of the pattern.  However this might be inefficient. 
	 */
	public static int streamFind(InputStream is, byte[] pattern)
		throws IOException
	{
		
		byte[] windowBuffer = new byte[pattern.length];
		if (readCompletely(is, windowBuffer) == windowBuffer.length)
		{
			//pattern is not empty?
			int distance = 0;
			if (pattern.length > 0)
			{
				CircularByteQueue window = new CircularByteQueue(windowBuffer, true);
				int b;
				while (!window.equals(pattern))
				{
					b = is.read();
					distance++;
					if (b != -1)
						window.put((byte)b);
					else
						return -1;
				}
			}
			
			return distance;
		}
		else
			return -1;
	}
	
	public static String readTextStream(InputStream is, Charset charset)
		throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(is, charset), 1024);
		StringBuilder sb = new StringBuilder(1024);
		
		String line = br.readLine();
		while (line != null)
		{
			sb.append(line);
			sb.append('\n');
			line = br.readLine();
		}
		
		return sb.toString();
	}
	
	public Util(){}
	
	@Test
	public void streamFindTest()
		throws IOException
	{
		//streamFind
		{
			ByteArrayInputStream is;
			
			//empty stream, empty pattern
			{
				is = new ByteArrayInputStream(new byte[0]);
				assertTrue(Util.streamFind(is, new byte[0]) == 0);
			}
			
			//empty stream, non-empty pattern
			{
				is = new ByteArrayInputStream(new byte[0]);
				assertTrue(Util.streamFind(is, new byte[1]) == -1);
			}
			
			//non-empty stream, empty pattern
			{
				is = new ByteArrayInputStream(new byte[1]);
				assertTrue(Util.streamFind(is, new byte[0]) == 0);
			}
			
			//1 stream, 1 pattern
			{
				is = new ByteArrayInputStream(new byte[]{Byte.MIN_VALUE});
				assertTrue(Util.streamFind(is, new byte[]{Byte.MIN_VALUE}) == 0);
				assertTrue(is.read() == -1);
			}
			
			//2 stream, 1 pattern
			{
				is = new ByteArrayInputStream(new byte[]{126,Byte.MAX_VALUE});
				assertTrue(Util.streamFind(is, new byte[]{Byte.MAX_VALUE}) == 1);
				assertTrue(is.read() == -1);
			}
			
			//2 stream, 1 pattern
			{
				is = new ByteArrayInputStream(new byte[]{126,127});
				assertTrue(Util.streamFind(is, new byte[]{126}) == 0);
				assertTrue(is.read() == 127);
			}
			
			//2 stream, 3 pattern
			{
				is = new ByteArrayInputStream(new byte[]{1,2});
				assertTrue(Util.streamFind(is, new byte[]{1,2,3}) == -1);
				assertTrue(is.read() == -1);
			}
			
			{
				is = new ByteArrayInputStream("HelloJelloFellow".getBytes());
				assertTrue(Util.streamFind(is, "Hello".getBytes()) == 0);
				assertTrue(is.read() == 'J');
				assertTrue(Util.streamFind(is, "Hello".getBytes()) == -1);
				assertTrue(is.read() == -1);
			}
			
			{
				is = new ByteArrayInputStream("HelloJelloFellow".getBytes());
				assertTrue(Util.streamFind(is, "ello".getBytes()) == 1);
				assertTrue(is.read() == 'J');
				assertTrue(Util.streamFind(is, "ello".getBytes()) == 0);
				assertTrue(is.read() == 'F');
				assertTrue(Util.streamFind(is, "ello".getBytes()) == 0);
				assertTrue(is.read() == 'w');
				assertTrue(Util.streamFind(is, "ello".getBytes()) == -1);
				assertTrue(is.read() == -1);
			}
			
			{
				is = new ByteArrayInputStream("HelloJelloFellow".getBytes());
				assertTrue(Util.streamFind(is, "Fell".getBytes()) == 10);
				assertTrue(Util.streamFind(is, "w".getBytes()) == 1);
				assertTrue(is.read() == -1);
			}			
		}
	}	
}
